"""Domain module tests."""
