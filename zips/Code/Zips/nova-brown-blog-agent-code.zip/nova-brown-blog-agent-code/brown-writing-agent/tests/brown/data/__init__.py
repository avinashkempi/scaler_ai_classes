"""Data module tests."""
