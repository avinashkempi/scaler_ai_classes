"""Brown module tests."""
